# -*- coding: utf-8 -*-
import scrapy

from scrapy.http import Request
#from scrapy.linkextractors import LinkExtractor
from scrapy.loader import ItemLoader
# from scrapy.spiders import CrawlSpider, Rule, BaseSpider, Spider
from scrapy.spiders import Spider
#import MySQLdb
import datetime
from scrapy.exceptions import CloseSpider
# menulis pesan di log
import logging
# parsing again from extracted tag (jika sudah di extract()) atau untuk membuat selector dari string
# from scrapy.selector import Selector
# from scrapy.http import HtmlResponse
# for error
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError
from twisted.internet.error import TimeoutError, TCPTimedOutError
from datetime import date
from jatengnews.items import JatengnewsItem
class Jateng(scrapy.Spider):
    name = "berita_jateng"

    def start_requests(self):
        yield self.make_requests_from_url("https://jateng.antaranews.com/daerah")
        #yield scrapy.Request(url='https://jateng.antaranews.com/daerah', callback=self.parse)

    def parse(self,response):
        
        x_links = response.xpath('//div[@class="row"]//div[@class="col-md-8"]').css('.simple-post').xpath('./header/h3/a/@href').extract()
        x_link = response.xpath('//div[@class="row"]//div[@class="col-md-8"]').css('.simple-post').xpath('./header/h3/a/@href').extract()
        
        self.logger.info(x_links)
        for link,link2 in zip(x_links,x_link):
            yield scrapy.Request(
                response.urljoin(link),
                callback=self.parse_item,
                meta = {'link':link}
                )
    
    def parse_item(self,response):
        item = JatengnewsItem()
        judul = response.xpath('//header/h1[@class="post-title"]/text()').extract_first()
        isi = response.xpath('//article/div[@itemprop="articleBody"]').extract()
        item['judul']= judul
        item['isi']= isi
        self.logger.info("judul = %s",judul)
        self.logger.info("isi %s",isi )

        return item
        
