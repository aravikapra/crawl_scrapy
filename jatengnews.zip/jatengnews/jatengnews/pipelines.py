# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import MySQLdb
import logging

class JatengnewsPipeline(object):
    def __init__(self):
        self.conn = MySQLdb.connect(
            user='root',
            password='',
            db='dbcrawl_jatengnews',
            host='localhost',
            charset="utf8",
            use_unicode=True
        )
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        try:
            self.cursor.execute("""INSERT INTO tb_crawl(judul, isi) VALUES (%s, %s)""",(item['judul'],item['isi']))
            self.conn.commit()
            self.logger.info("pipeline terpanggil di tidak error")
        except MySQLdb.Error as e:
            print ("Error %d: %s" % (e.args[0], e.args[1]))
            self.logger.info("pipeline terpanggil di error")

        return item
